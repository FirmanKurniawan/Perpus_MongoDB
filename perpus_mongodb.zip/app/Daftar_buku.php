<?php

namespace App;

use Jenssegers\Mongodb\Eloquent\Model as Eloquent;

class Daftar_buku extends Eloquent
{
    //
}
