<?php

namespace App;

use Jenssegers\Mongodb\Eloquent\Model as Eloquent;

class Stok_buku extends Eloquent
{
    //
}
